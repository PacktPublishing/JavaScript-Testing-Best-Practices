import {app} from './app';

new Vue({
    el: "#app",
    ...app
});
